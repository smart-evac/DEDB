export type ScenarioId = 'clear' | 'fire' | 'flood' | 'gas' | 'quake'
export type ZoneStatus = 'safe' | 'caution' | 'danger' | 'blocked'
export type ZoneId =
  | 'north'
  | 'A'
  | 'B'
  | 'C'
  | 'central'
  | 'D'
  | 'E'
  | 'stairL'
  | 'stairR'

export type ExitSide = 'left' | 'right' | 'both'

export interface Zone {
  id: ZoneId
  label: string
  room?: string
}

export interface SensorReading {
  key: 'temperature' | 'smoke' | 'water' | 'gas' | 'seismic'
  label: string
  value: number
  unit: string
  status: 'normal' | 'warning' | 'critical'
  /** 0-100 fill for the bar */
  fill: number
}

export interface Alert {
  id: string
  time: string
  zone: string
  message: string
  level: Exclude<ZoneStatus, 'safe'>
}

export interface Scenario {
  id: ScenarioId
  name: string
  short: string
  detail: string
  /** status level driving the banner + header */
  level: 'normal' | 'caution' | 'danger'
  message: string
  /** which side holds the safe exit */
  safeExit: ExitSide
  /** direction display copy */
  direction: string
  evacuationPath: string
  zones: Record<ZoneId, ZoneStatus>
  alerts: Alert[]
}

export const ZONE_LIST: Zone[] = [
  { id: 'north', label: 'North Corridor' },
  { id: 'A', label: 'Zone A', room: 'Room 101' },
  { id: 'B', label: 'Zone B', room: 'Room 102-103' },
  { id: 'C', label: 'Zone C', room: 'Room 104' },
  { id: 'central', label: 'Central Corridor' },
  { id: 'D', label: 'Zone D', room: 'Room 201' },
  { id: 'E', label: 'Zone E', room: 'Room 202-203' },
  { id: 'stairL', label: 'West Stair', room: 'Exit A' },
  { id: 'stairR', label: 'East Stair', room: 'Exit B' },
]

const allSafe: Record<ZoneId, ZoneStatus> = {
  north: 'safe',
  A: 'safe',
  B: 'safe',
  C: 'safe',
  central: 'safe',
  D: 'safe',
  E: 'safe',
  stairL: 'safe',
  stairR: 'safe',
}

export const SCENARIOS: Record<ScenarioId, Scenario> = {
  clear: {
    id: 'clear',
    name: 'All Clear',
    short: 'No incident',
    detail: 'All monitored zones report normal readings.',
    level: 'normal',
    message: 'ALL SYSTEMS NORMAL — No active incidents detected.',
    safeExit: 'both',
    direction: 'ALL EXITS OPEN',
    evacuationPath: 'System normal — standard exit signage in effect.',
    zones: { ...allSafe },
    alerts: [],
  },
  fire: {
    id: 'fire',
    name: 'Fire',
    short: 'Left wing ablaze',
    detail: 'Fire detected in the west wing. West stair and exit blocked.',
    level: 'danger',
    message: 'FIRE DETECTED — West wing ablaze. Reroute to the East exit now.',
    safeExit: 'right',
    direction: 'SAFE EXIT →',
    evacuationPath: 'Zone A → Central Corridor → East Stair → East Exit',
    zones: {
      ...allSafe,
      A: 'danger',
      north: 'caution',
      B: 'caution',
      stairL: 'blocked',
      D: 'caution',
    },
    alerts: [
      { id: 'f1', time: '00:00', zone: 'Zone A', message: 'Fire detected — west wing ablaze', level: 'danger' },
      { id: 'f2', time: '00:02', zone: 'Zone A', message: 'Smoke density critical (480 ppm)', level: 'danger' },
      { id: 'f3', time: '00:03', zone: 'West Stair', message: 'Primary exit blocked — rerouting', level: 'blocked' },
      { id: 'f4', time: '00:05', zone: 'Zone B', message: 'Elevated temperature — evacuate', level: 'caution' },
    ],
  },
  flood: {
    id: 'flood',
    name: 'Flood',
    short: 'Ground floor flooded',
    detail: 'Rising water on the ground level. Move to higher zones.',
    level: 'danger',
    message: 'FLOOD WARNING — Ground level flooding. Ascend via East Stair to higher ground.',
    safeExit: 'right',
    direction: 'HIGHER GROUND →',
    evacuationPath: 'Zone A → Central Corridor → East Stair → Upper Floor',
    zones: {
      ...allSafe,
      A: 'danger',
      B: 'danger',
      north: 'caution',
      stairL: 'blocked',
      D: 'caution',
    },
    alerts: [
      { id: 'w1', time: '00:00', zone: 'Zone A', message: 'Water level rising rapidly (85 cm)', level: 'danger' },
      { id: 'w2', time: '00:01', zone: 'Zone B', message: 'Ground level flooding detected', level: 'danger' },
      { id: 'w3', time: '00:04', zone: 'West Stair', message: 'Lower exit submerged — blocked', level: 'blocked' },
    ],
  },
  gas: {
    id: 'gas',
    name: 'Gas Leak',
    short: 'Zone B compromised',
    detail: 'Hazardous gas concentration in Zone B. Ventilate and clear the area.',
    level: 'danger',
    message: 'GAS LEAK — Zone B compromised. Evacuate away from the leak via nearest safe exit.',
    safeExit: 'left',
    direction: '← SAFE EXIT',
    evacuationPath: 'Zone B → Central Corridor → West Stair → West Exit',
    zones: {
      ...allSafe,
      B: 'danger',
      A: 'caution',
      C: 'caution',
      central: 'caution',
      stairR: 'blocked',
    },
    alerts: [
      { id: 'g1', time: '00:00', zone: 'Zone B', message: 'Gas concentration critical (780 ppm)', level: 'danger' },
      { id: 'g2', time: '00:02', zone: 'Zone A', message: 'Trace gas detected — caution', level: 'caution' },
      { id: 'g3', time: '00:03', zone: 'East Stair', message: 'Exit sealed to contain leak', level: 'blocked' },
    ],
  },
  quake: {
    id: 'quake',
    name: 'Earthquake',
    short: 'Structural alert',
    detail: 'Seismic activity detected. Avoid damaged corridors, use stable routes.',
    level: 'caution',
    message: 'SEISMIC ALERT — Structural integrity compromised. Use marked stable routes only.',
    safeExit: 'both',
    direction: 'STABLE ROUTE',
    evacuationPath: 'Nearest zone → Reinforced Central Corridor → Ground Exit',
    zones: {
      ...allSafe,
      north: 'danger',
      A: 'caution',
      B: 'caution',
      C: 'caution',
      D: 'caution',
      E: 'caution',
      central: 'safe',
    },
    alerts: [
      { id: 'q1', time: '00:00', zone: 'North Corridor', message: 'Seismic activity 6.4R — structural alert', level: 'danger' },
      { id: 'q2', time: '00:02', zone: 'All Zones', message: 'Aftershock risk — move to open areas', level: 'caution' },
      { id: 'q3', time: '00:04', zone: 'Central Corridor', message: 'Reinforced route verified stable', level: 'caution' },
    ],
  },
}

export const SCENARIO_ORDER: ScenarioId[] = ['clear', 'fire', 'flood', 'gas', 'quake']

interface SensorTemplate {
  key: SensorReading['key']
  label: string
  unit: string
  base: number
  /** value shown for a caution zone in this scenario */
  warn?: number
  /** value shown for a danger/blocked zone in this scenario */
  crit?: number
  /** value used to normalize the fill bar */
  max: number
}

const SENSOR_TEMPLATES: Record<SensorReading['key'], SensorTemplate> = {
  temperature: { key: 'temperature', label: 'Temperature', unit: '°C', base: 22, warn: 46, crit: 71, max: 90 },
  smoke: { key: 'smoke', label: 'Smoke Density', unit: 'ppm', base: 5, warn: 150, crit: 480, max: 600 },
  water: { key: 'water', label: 'Water Level', unit: 'cm', base: 2, warn: 32, crit: 85, max: 100 },
  gas: { key: 'gas', label: 'Gas Concentration', unit: 'ppm', base: 3, warn: 210, crit: 780, max: 900 },
  seismic: { key: 'seismic', label: 'Seismic Activity', unit: 'R', base: 0, warn: 3.8, crit: 6.4, max: 9 },
}

const SCENARIO_METRIC: Record<ScenarioId, SensorReading['key'] | null> = {
  clear: null,
  fire: 'temperature',
  flood: 'water',
  gas: 'gas',
  quake: 'seismic',
}

// Fire elevates two metrics; handled specially.
export function getSensorReadings(scenarioId: ScenarioId, zoneStatus: ZoneStatus): SensorReading[] {
  const primary = SCENARIO_METRIC[scenarioId]
  const elevatedKeys = new Set<SensorReading['key']>()
  if (primary) elevatedKeys.add(primary)
  if (scenarioId === 'fire') elevatedKeys.add('smoke')

  return (Object.keys(SENSOR_TEMPLATES) as SensorReading['key'][]).map((key) => {
    const tpl = SENSOR_TEMPLATES[key]
    let value = tpl.base
    let status: SensorReading['status'] = 'normal'

    if (elevatedKeys.has(key) && zoneStatus !== 'safe') {
      if (zoneStatus === 'danger' || zoneStatus === 'blocked') {
        value = tpl.crit ?? tpl.base
        status = 'critical'
      } else if (zoneStatus === 'caution') {
        value = tpl.warn ?? tpl.base
        status = 'warning'
      }
    }

    const fill = Math.min(100, Math.round((value / tpl.max) * 100))
    return { key, label: tpl.label, value, unit: tpl.unit, status, fill }
  })
}

export function statusColorVar(status: ZoneStatus): string {
  return `var(--${status})`
}
