import { Bell, Boxes, Brain, Layers, Map, Mic, Users, Wifi } from 'lucide-react'
import { SectionHeading } from './section-heading'

const ITEMS = [
  { icon: Brain, name: 'AI Route Optimization', desc: 'Predict hazard spread and pre-compute the best routes.' },
  { icon: Wifi, name: 'IoT Sensor Mesh', desc: 'Dense, self-healing networks of connected detectors.' },
  { icon: Users, name: 'Crowd Analysis', desc: 'Balance flow to prevent bottlenecks and crushes.' },
  { icon: Map, name: 'Indoor Mapping', desc: 'Turn-by-turn navigation on real building maps.' },
  { icon: Bell, name: 'Mobile Alerts', desc: 'Push targeted guidance to every occupant’s phone.' },
  { icon: Mic, name: 'Voice Guidance', desc: 'Spoken directions for low-visibility conditions.' },
  { icon: Layers, name: 'Multi-Floor Planning', desc: 'Coordinate evacuation across every level at once.' },
  { icon: Boxes, name: 'BMS Integration', desc: 'Link with building-management and fire systems.' },
]

export function FutureScope() {
  return (
    <section id="future" className="scroll-mt-20 px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="Future Scope"
          title="Where Escape Smartly goes next"
          description="A roadmap toward a fully autonomous, intelligent evacuation network."
        />

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {ITEMS.map((item) => (
            <div
              key={item.name}
              className="group relative overflow-hidden rounded-lg border border-border bg-panel/70 p-5 transition-colors hover:border-info/50"
            >
              <span className="grid size-11 place-items-center rounded-md border border-info/30 bg-info/10 text-info">
                <item.icon className="size-5" aria-hidden />
              </span>
              <h3 className="mt-3 font-mono text-sm font-bold uppercase tracking-wider text-foreground">{item.name}</h3>
              <p className="mt-1 font-mono text-xs leading-relaxed text-muted-foreground">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
