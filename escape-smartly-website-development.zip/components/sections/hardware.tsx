import { BatteryCharging, Cpu, Hand, Lightbulb, Radar, RotateCw } from 'lucide-react'
import { SectionHeading } from './section-heading'

const PARTS = [
  { icon: Cpu, name: 'ESP32 Controller', desc: 'Low-power microcontroller running the decision logic on the edge.' },
  { icon: Radar, name: 'Smoke / Temp / Crowd Sensors', desc: 'Detect hazards and occupancy density across every zone.' },
  { icon: Lightbulb, name: 'LED / LCD Indicators', desc: 'High-visibility status and messaging at each junction.' },
  { icon: RotateCw, name: 'Servo Direction Signs', desc: 'Physically rotate arrows to point toward the safe exit.' },
  { icon: BatteryCharging, name: 'Battery Backup', desc: 'Keeps guidance live even during a power failure.' },
  { icon: Hand, name: 'Manual Override', desc: 'Lets safety staff take direct control when required.' },
]

export function Hardware() {
  return (
    <section id="hardware" className="scroll-mt-20 border-t border-border bg-panel/30 px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-7xl">
        <div className="mx-auto mb-8 flex max-w-2xl justify-center">
          <p className="flex items-center gap-2 rounded-full border border-caution/40 bg-caution/10 px-4 py-1.5 text-center font-mono text-[11px] font-semibold uppercase tracking-wider text-caution">
            <span className="size-2 rounded-full bg-caution" aria-hidden />
            Prototype stage — this is a web concept demonstration; hardware is proposed, not yet built
          </p>
        </div>

        <SectionHeading
          eyebrow="Proposed Hardware"
          title="How DEDB becomes a physical system"
          description="The next phase pairs this decision engine with affordable, resilient hardware installed throughout a building."
        />

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {PARTS.map((part) => (
            <div key={part.name} className="flex gap-4 rounded-lg border border-border bg-panel/70 p-5">
              <span className="grid size-11 shrink-0 place-items-center rounded-md border border-primary/30 bg-primary/10 text-primary">
                <part.icon className="size-5" aria-hidden />
              </span>
              <div>
                <h3 className="font-mono text-sm font-bold uppercase tracking-wider text-foreground">{part.name}</h3>
                <p className="mt-1 font-mono text-xs leading-relaxed text-muted-foreground">{part.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
