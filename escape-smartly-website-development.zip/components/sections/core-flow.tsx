import { ArrowRight, Compass, Radar, Route, ScanSearch, Siren, Users } from 'lucide-react'
import { SectionHeading } from './section-heading'

const STEPS = [
  { icon: Siren, title: 'Emergency Detection', desc: 'Sensors flag fire, smoke, heat, gas, flooding, or crowding the instant it appears.' },
  { icon: ScanSearch, title: 'Condition Analysis', desc: 'Live readings are scored per zone to classify each area as safe, caution, or danger.' },
  { icon: Radar, title: 'Route Evaluation', desc: 'Every corridor, stair, and exit is checked against current hazards and congestion.' },
  { icon: Route, title: 'Safer Route Selection', desc: 'The system picks the lowest-risk path and discards any blocked or unsafe exit.' },
  { icon: Compass, title: 'Dynamic Direction Display', desc: 'Signage flips in real time — a normal EXIT → becomes ← SAFE EXIT when needed.' },
  { icon: Users, title: 'User Evacuation', desc: 'Occupants follow clear, continuously updated guidance to the safest way out.' },
]

export function CoreFlow() {
  return (
    <section id="flow" className="scroll-mt-20 border-t border-border bg-panel/30 px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="How It Works"
          title="From hazard to safe exit in six steps"
          description="DEDB runs a continuous decision loop so evacuation guidance always reflects what is happening right now."
        />

        <ol className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {STEPS.map((step, i) => (
            <li
              key={step.title}
              className="group relative flex flex-col gap-3 rounded-lg border border-border bg-panel/70 p-5 transition-colors hover:border-primary/50"
            >
              <div className="flex items-center justify-between">
                <span className="grid size-11 place-items-center rounded-md border border-primary/30 bg-primary/10 text-primary transition-colors group-hover:bg-primary/20">
                  <step.icon className="size-5" aria-hidden />
                </span>
                <span className="font-mono text-3xl font-black text-border transition-colors group-hover:text-primary/30">
                  {String(i + 1).padStart(2, '0')}
                </span>
              </div>
              <h3 className="font-mono text-sm font-bold uppercase tracking-wider text-foreground">{step.title}</h3>
              <p className="font-mono text-xs leading-relaxed text-muted-foreground">{step.desc}</p>
              {(i + 1) % 3 !== 0 && i < STEPS.length - 1 ? (
                <ArrowRight
                  className="absolute -right-3 top-1/2 hidden size-5 -translate-y-1/2 text-primary/40 lg:block"
                  aria-hidden
                />
              ) : null}
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
