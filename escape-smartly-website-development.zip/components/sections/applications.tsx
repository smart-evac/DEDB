import { Building, Building2, Factory, GraduationCap, Hospital, Landmark, ShoppingBag, TrainFront } from 'lucide-react'
import { SectionHeading } from './section-heading'

const APPS = [
  { icon: Hospital, name: 'Hospitals', desc: 'Guide patients and staff through complex wards.' },
  { icon: GraduationCap, name: 'Schools & Colleges', desc: 'Route large student populations calmly.' },
  { icon: ShoppingBag, name: 'Malls', desc: 'Handle dense, unfamiliar crowds fast.' },
  { icon: TrainFront, name: 'Metro Stations', desc: 'Move commuters through tight platforms.' },
  { icon: Building2, name: 'Offices', desc: 'Coordinate multi-floor building egress.' },
  { icon: Factory, name: 'Industries', desc: 'Respond to chemical, gas, and fire risk.' },
  { icon: Landmark, name: 'Public Venues', desc: 'Manage stadiums, halls, and events.' },
  { icon: Building, name: 'High-Rises', desc: 'Plan safe vertical evacuation routes.' },
]

export function Applications() {
  return (
    <section id="applications" className="scroll-mt-20 px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="Applications"
          title="Built for any building with people to protect"
          description="Wherever crowds gather and exits matter, DEDB keeps evacuation routes safe and adaptive."
        />

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {APPS.map((app) => (
            <div
              key={app.name}
              className="group flex flex-col gap-3 rounded-lg border border-border bg-panel/70 p-5 transition-all hover:-translate-y-1 hover:border-primary/50"
            >
              <span className="grid size-12 place-items-center rounded-md border border-border bg-secondary/50 text-primary transition-colors group-hover:bg-primary/15">
                <app.icon className="size-6" aria-hidden />
              </span>
              <h3 className="font-mono text-sm font-bold uppercase tracking-wider text-foreground">{app.name}</h3>
              <p className="font-mono text-xs leading-relaxed text-muted-foreground">{app.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
