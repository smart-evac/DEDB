interface SectionHeadingProps {
  eyebrow: string
  title: string
  description?: string
}

export function SectionHeading({ eyebrow, title, description }: SectionHeadingProps) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">
        <span aria-hidden>◈</span>
        {eyebrow}
      </span>
      <h2 className="mt-4 text-balance font-sans text-2xl font-bold tracking-tight text-foreground sm:text-3xl md:text-4xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-3 text-pretty font-mono text-sm leading-relaxed text-muted-foreground">{description}</p>
      ) : null}
    </div>
  )
}
