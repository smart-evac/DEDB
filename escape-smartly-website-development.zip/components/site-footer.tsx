import { Siren } from 'lucide-react'

const LINKS = [
  { label: 'Live Board', href: '#board' },
  { label: 'How It Works', href: '#flow' },
  { label: 'Applications', href: '#applications' },
  { label: 'Hardware', href: '#hardware' },
  { label: 'Future Scope', href: '#future' },
]

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-panel/40 px-4 py-10 sm:px-6">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 md:flex-row md:items-start md:justify-between">
        <div className="max-w-sm">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-md bg-gradient-to-br from-primary to-info text-primary-foreground">
              <Siren className="size-4.5" aria-hidden />
            </span>
            <span className="font-sans text-base font-bold text-foreground">Escape Smartly</span>
          </div>
          <p className="mt-3 font-mono text-xs leading-relaxed text-muted-foreground">
            The Dynamic Evacuation Decision Board — intelligent, real-time evacuation guidance that adapts the instant a
            route becomes unsafe.
          </p>
          <p className="mt-3 font-mono text-[11px] uppercase tracking-wider text-caution">
            Prototype concept · Hackathon demonstration
          </p>
        </div>

        <nav aria-label="Footer" className="flex flex-col gap-2">
          <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary">Explore</span>
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="font-mono text-xs text-muted-foreground transition-colors hover:text-primary"
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>

      <div className="mx-auto mt-8 flex max-w-7xl flex-col gap-2 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between">
        <p className="font-mono text-[11px] text-muted-foreground">
          © {new Date().getFullYear()} Escape Smartly · DEDB v1.0
        </p>
        <p className="font-mono text-[11px] text-muted-foreground">
          Built as an original, independent project demonstration.
        </p>
      </div>
    </footer>
  )
}
