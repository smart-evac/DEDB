'use client'

import { useEffect, useState } from 'react'
import { Menu, Siren, X } from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV = [
  { label: 'Live Board', href: '#board' },
  { label: 'How It Works', href: '#flow' },
  { label: 'Applications', href: '#applications' },
  { label: 'Hardware', href: '#hardware' },
  { label: 'Future', href: '#future' },
]

export function SiteHeader() {
  const [now, setNow] = useState<Date | null>(null)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    setNow(new Date())
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  const handleNav = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    setOpen(false)
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <a
          href="#board"
          onClick={(e) => handleNav(e, '#board')}
          className="flex items-center gap-3"
          aria-label="Escape Smartly home"
        >
          <span className="grid size-10 place-items-center rounded-md bg-gradient-to-br from-primary to-info text-primary-foreground shadow-lg shadow-primary/30">
            <Siren className="size-5" aria-hidden />
          </span>
          <span className="leading-tight">
            <span className="block font-sans text-sm font-bold tracking-tight text-foreground sm:text-base">
              Escape Smartly
            </span>
            <span className="block font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              DEDB v1.0 · Disaster Response
            </span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => handleNav(e, item.href)}
              className="rounded-md px-3 py-2 font-mono text-xs uppercase tracking-wider text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-3 sm:flex">
            <span className="flex items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-3 py-1.5">
              <span className="size-2 animate-pulse rounded-full bg-primary" aria-hidden />
              <span className="font-mono text-[11px] font-semibold uppercase tracking-widest text-primary">
                Operational
              </span>
            </span>
            <time className="font-mono text-[11px] tabular-nums text-muted-foreground" suppressHydrationWarning>
              {now
                ? now.toLocaleString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                  })
                : '—'}
            </time>
          </div>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="grid size-9 place-items-center rounded-md border border-border text-foreground lg:hidden"
            aria-expanded={open}
            aria-label={open ? 'Close menu' : 'Open menu'}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      <div
        className={cn(
          'overflow-hidden border-t border-border transition-[max-height] duration-300 lg:hidden',
          open ? 'max-h-96' : 'max-h-0',
        )}
      >
        <nav className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-3" aria-label="Mobile">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => handleNav(e, item.href)}
              className="rounded-md px-3 py-2.5 font-mono text-sm uppercase tracking-wider text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
            >
              {item.label}
            </a>
          ))}
          <span className="mt-1 flex items-center gap-2 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-primary">
            <span className="size-2 animate-pulse rounded-full bg-primary" aria-hidden />
            System Operational
          </span>
        </nav>
      </div>
    </header>
  )
}
