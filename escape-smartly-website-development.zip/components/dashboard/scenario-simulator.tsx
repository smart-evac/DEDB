'use client'

import { Flame, ShieldCheck, Waves, Wind, Zap, type LucideIcon } from 'lucide-react'
import { SCENARIO_ORDER, SCENARIOS, type ScenarioId } from '@/lib/dedb'
import { Panel } from './panel'
import { useDashboard } from './dashboard-context'
import { cn } from '@/lib/utils'

const ICONS: Record<ScenarioId, LucideIcon> = {
  clear: ShieldCheck,
  fire: Flame,
  flood: Waves,
  gas: Wind,
  quake: Zap,
}

const ACTIVE_COLOR: Record<ScenarioId, string> = {
  clear: 'text-safe',
  fire: 'text-danger',
  flood: 'text-info',
  gas: 'text-caution',
  quake: 'text-caution',
}

export function ScenarioSimulator() {
  const { scenarioId, setScenarioId } = useDashboard()

  return (
    <Panel title="Scenario Simulator">
      <p className="mb-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
        Trigger a hazard to watch the board recompute safe exits in real time.
      </p>
      <div className="flex flex-col gap-2">
        {SCENARIO_ORDER.map((id) => {
          const scenario = SCENARIOS[id]
          const Icon = ICONS[id]
          const active = scenarioId === id
          return (
            <button
              key={id}
              type="button"
              onClick={() => setScenarioId(id)}
              aria-pressed={active}
              className={cn(
                'group flex items-center gap-3 rounded-md border px-3 py-3 text-left transition-all',
                active
                  ? 'border-primary/60 bg-primary/10 glow-primary'
                  : 'border-border bg-secondary/40 hover:border-primary/40 hover:bg-secondary',
              )}
            >
              <span
                className={cn(
                  'grid size-9 shrink-0 place-items-center rounded-md border border-border bg-background/60',
                  active ? ACTIVE_COLOR[id] : 'text-muted-foreground group-hover:text-foreground',
                )}
              >
                <Icon className="size-4.5" aria-hidden />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold uppercase tracking-wider text-foreground">
                    {scenario.name}
                  </span>
                  {active ? (
                    <span className="rounded-sm bg-primary/20 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-widest text-primary">
                      Active
                    </span>
                  ) : null}
                </span>
                <span className="mt-0.5 block truncate font-mono text-[11px] text-muted-foreground">
                  {scenario.short}
                </span>
              </span>
            </button>
          )
        })}
      </div>
    </Panel>
  )
}
