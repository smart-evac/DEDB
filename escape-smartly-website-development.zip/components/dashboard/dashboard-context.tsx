'use client'

import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'
import {
  SCENARIOS,
  getSensorReadings,
  type Scenario,
  type ScenarioId,
  type SensorReading,
  type ZoneId,
} from '@/lib/dedb'

interface DashboardState {
  scenarioId: ScenarioId
  setScenarioId: (id: ScenarioId) => void
  scenario: Scenario
  selectedZone: ZoneId
  setSelectedZone: (id: ZoneId) => void
  selectedZoneStatus: ReturnType<typeof getSelectedStatus>
  sensors: SensorReading[]
  manualOverride: boolean
  setManualOverride: (v: boolean) => void
}

function getSelectedStatus(scenario: Scenario, zone: ZoneId) {
  return scenario.zones[zone]
}

const DashboardContext = createContext<DashboardState | null>(null)

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [scenarioId, setScenarioIdState] = useState<ScenarioId>('clear')
  const [selectedZone, setSelectedZone] = useState<ZoneId>('A')
  const [manualOverride, setManualOverride] = useState(false)

  // Changing the scenario clears any manual override latch.
  const setScenarioId = (id: ScenarioId) => {
    setManualOverride(false)
    setScenarioIdState(id)
  }

  const value = useMemo<DashboardState>(() => {
    const scenario = SCENARIOS[scenarioId]
    const selectedZoneStatus = getSelectedStatus(scenario, selectedZone)
    const sensors = getSensorReadings(scenarioId, selectedZoneStatus)
    return {
      scenarioId,
      setScenarioId,
      scenario,
      selectedZone,
      setSelectedZone,
      selectedZoneStatus,
      sensors,
      manualOverride,
      setManualOverride,
    }
  }, [scenarioId, selectedZone, manualOverride])

  return <DashboardContext.Provider value={value}>{children}</DashboardContext.Provider>
}

export function useDashboard() {
  const ctx = useContext(DashboardContext)
  if (!ctx) throw new Error('useDashboard must be used within DashboardProvider')
  return ctx
}
