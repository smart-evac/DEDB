'use client'

import { DashboardProvider } from './dashboard-context'
import { ScenarioSimulator } from './scenario-simulator'
import { FloorPlan } from './floor-plan'
import { EvacuationBoard } from './evacuation-board'
import { ZoneMonitor, ManualOverride } from './zone-monitor'
import { SystemStatusCard, EvacuationPath, AlertLog, StatusBanner } from './status-panels'

export function Dashboard() {
  return (
    <DashboardProvider>
      <section id="board" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-10 sm:px-6 sm:py-14">
        <div className="mb-8 max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">
            Live Decision Board
          </span>
          <h1 className="mt-4 text-balance font-sans text-3xl font-bold tracking-tight text-foreground sm:text-4xl md:text-5xl">
            Dynamic Evacuation Decision Board
          </h1>
          <p className="mt-3 text-pretty font-mono text-sm leading-relaxed text-muted-foreground sm:text-base">
            When fire, smoke, flood, gas, crowding, or structural hazards make a normal route unsafe, DEDB detects the
            threat, re-evaluates every path, and flips exit signage toward the safest way out — in real time. Trigger a
            scenario below to see it react.
          </p>
        </div>

        <div className="grid gap-4 lg:grid-cols-12">
          <div className="flex flex-col gap-4 lg:col-span-3">
            <ScenarioSimulator />
            <SystemStatusCard />
            <EvacuationPath />
          </div>

          <div className="flex flex-col gap-4 lg:col-span-6">
            <FloorPlan />
            <StatusBanner />
            <EvacuationBoard />
          </div>

          <div className="flex flex-col gap-4 lg:col-span-3">
            <AlertLog />
            <ZoneMonitor />
            <ManualOverride />
          </div>
        </div>
      </section>
    </DashboardProvider>
  )
}
