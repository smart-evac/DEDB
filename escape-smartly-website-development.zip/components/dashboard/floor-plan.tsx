'use client'

import { ArrowLeft, ArrowRight, MapPin } from 'lucide-react'
import type { ZoneId, ZoneStatus } from '@/lib/dedb'
import { Panel } from './panel'
import { useDashboard } from './dashboard-context'
import { cn } from '@/lib/utils'

const STATUS_LABEL: Record<ZoneStatus, string> = {
  safe: 'Safe',
  caution: 'Caution',
  danger: 'Danger',
  blocked: 'Blocked',
}

function ZoneBox({
  id,
  label,
  room,
  className,
}: {
  id: ZoneId
  label: string
  room?: string
  className?: string
}) {
  const { scenario, selectedZone, setSelectedZone } = useDashboard()
  const status = scenario.zones[id]
  const selectable = ['A', 'B', 'C', 'D', 'E'].includes(id)
  const selected = selectedZone === id

  const content = (
    <>
      <span className="font-mono text-xs font-bold uppercase tracking-wider">{label}</span>
      {room ? <span className="font-mono text-[10px] text-muted-foreground">{room}</span> : null}
      <span
        className="mt-1 font-mono text-[9px] font-semibold uppercase tracking-widest"
        style={{ color: `var(--${status})` }}
      >
        {selected ? '▶ Selected' : STATUS_LABEL[status]}
      </span>
    </>
  )

  const common =
    'zone flex flex-col items-center justify-center gap-0.5 rounded-md px-2 py-4 text-center min-h-20'

  if (!selectable) {
    return (
      <div className={cn(common, className)} data-status={status}>
        {content}
      </div>
    )
  }

  return (
    <button
      type="button"
      onClick={() => setSelectedZone(id)}
      data-status={status}
      data-selected={selected}
      aria-pressed={selected}
      className={cn(common, 'cursor-pointer transition-transform hover:-translate-y-0.5', className)}
    >
      {content}
    </button>
  )
}

function StairColumn({ id, side }: { id: 'stairL' | 'stairR'; side: 'left' | 'right' }) {
  const { scenario } = useDashboard()
  const status = scenario.zones[id]
  const blocked = status === 'blocked'
  const isSafeExit = scenario.safeExit === side || scenario.safeExit === 'both'

  return (
    <div
      className="zone flex flex-col items-center justify-between gap-2 rounded-md px-1.5 py-4"
      data-status={status}
    >
      <span className="font-mono text-[10px] font-bold uppercase tracking-widest [writing-mode:vertical-rl] sm:[writing-mode:horizontal-tb]">
        Stair
      </span>
      <span
        className={cn(
          'flex items-center gap-1 rounded-sm border px-1.5 py-1 font-mono text-[9px] font-bold uppercase',
          blocked
            ? 'border-blocked/50 text-blocked line-through'
            : isSafeExit
              ? 'border-safe/50 text-safe'
              : 'border-border text-muted-foreground',
        )}
      >
        {side === 'left' ? <ArrowLeft className="size-3" /> : null}
        Exit
        {side === 'right' ? <ArrowRight className="size-3" /> : null}
      </span>
    </div>
  )
}

function ExitMarker({ safe, label }: { safe: boolean; label: string }) {
  return (
    <span
      className={cn(
        'flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 font-mono text-[10px] font-bold uppercase tracking-wider',
        safe ? 'border-safe/50 bg-safe/10 text-safe' : 'border-blocked/40 bg-blocked/10 text-blocked line-through',
      )}
    >
      <span
        className={cn('size-1.5 rounded-full', safe ? 'bg-safe' : 'bg-blocked')}
        aria-hidden
      />
      {label}
    </span>
  )
}

export function FloorPlan() {
  const { scenario } = useDashboard()
  const leftSafe = scenario.safeExit === 'left' || scenario.safeExit === 'both'
  const rightSafe = scenario.safeExit === 'right' || scenario.safeExit === 'both'

  return (
    <Panel
      title="Floor Plan — Building A · Ground Level"
      bodyClassName="p-3 sm:p-5"
      action={
        <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-primary">
          <MapPin className="size-3.5" aria-hidden /> Sector A
        </span>
      }
    >
      <div className="tactical-grid rounded-md border border-border/60 bg-background/40 p-3 sm:p-4">
        <div className="flex items-stretch gap-2 sm:gap-3">
          <StairColumn id="stairL" side="left" />

          <div className="flex flex-1 flex-col gap-2 sm:gap-3">
            <ZoneBox id="north" label="North Corridor" room="Main Hallway" className="min-h-14 py-3" />

            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              <ZoneBox id="A" label="Zone A" room="101" />
              <ZoneBox id="B" label="Zone B" room="102-103" />
              <ZoneBox id="C" label="Zone C" room="104" />
            </div>

            <ZoneBox id="central" label="Central Corridor" room="Reinforced" className="min-h-14 py-3" />

            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              <ZoneBox id="D" label="Zone D" room="201" />
              <ZoneBox id="E" label="Zone E" room="202-203" />
            </div>
          </div>

          <StairColumn id="stairR" side="right" />
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-center gap-2 sm:gap-4">
          <ExitMarker safe={leftSafe} label="West Exit" />
          <ExitMarker safe={rightSafe} label="East Exit" />
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2">
        {(['safe', 'caution', 'danger', 'blocked'] as ZoneStatus[]).map((s) => (
          <span key={s} className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            <span className="size-3 rounded-sm" style={{ backgroundColor: `var(--${s})` }} aria-hidden />
            {STATUS_LABEL[s]}
          </span>
        ))}
      </div>
    </Panel>
  )
}
