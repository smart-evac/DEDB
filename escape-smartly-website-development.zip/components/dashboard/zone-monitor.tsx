'use client'

import {
  Activity,
  Droplets,
  Gauge,
  Lock,
  LockOpen,
  MapPin,
  Thermometer,
  Wind,
  type LucideIcon,
} from 'lucide-react'
import { ZONE_LIST, type SensorReading, type ZoneId } from '@/lib/dedb'
import { Panel } from './panel'
import { useDashboard } from './dashboard-context'
import { cn } from '@/lib/utils'

const ZONE_CHIPS: { id: ZoneId; label: string }[] = [
  { id: 'A', label: 'ZN-A' },
  { id: 'B', label: 'ZN-B' },
  { id: 'C', label: 'ZN-C' },
  { id: 'D', label: 'ZN-D' },
  { id: 'E', label: 'ZN-E' },
  { id: 'stairL', label: 'STR-L' },
  { id: 'stairR', label: 'STR-R' },
  { id: 'north', label: 'COR-1' },
  { id: 'central', label: 'COR-2' },
]

const SENSOR_ICONS: Record<SensorReading['key'], LucideIcon> = {
  temperature: Thermometer,
  smoke: Wind,
  water: Droplets,
  gas: Gauge,
  seismic: Activity,
}

const SENSOR_STATUS_COLOR: Record<SensorReading['status'], string> = {
  normal: 'var(--safe)',
  warning: 'var(--caution)',
  critical: 'var(--danger)',
}

export function ZoneMonitor() {
  const { selectedZone, setSelectedZone, sensors, scenario } = useDashboard()
  const zone = ZONE_LIST.find((z) => z.id === selectedZone)
  const status = scenario.zones[selectedZone]

  return (
    <Panel title="Select Zone">
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-3">
        {ZONE_CHIPS.map((chip) => {
          const active = selectedZone === chip.id
          const chipStatus = scenario.zones[chip.id]
          return (
            <button
              key={chip.id}
              type="button"
              onClick={() => setSelectedZone(chip.id)}
              aria-pressed={active}
              className={cn(
                'flex items-center justify-center gap-1.5 rounded-md border px-2 py-2 font-mono text-[11px] font-semibold uppercase tracking-wider transition-all',
                active
                  ? 'border-primary/60 bg-primary/15 text-primary glow-primary'
                  : 'border-border bg-secondary/40 text-muted-foreground hover:border-primary/40 hover:text-foreground',
              )}
            >
              <span className="size-1.5 rounded-full" style={{ backgroundColor: `var(--${chipStatus})` }} aria-hidden />
              {chip.label}
            </button>
          )
        })}
      </div>

      <div className="mt-4 flex items-center gap-2.5 rounded-md border border-border bg-secondary/40 p-3">
        <MapPin className="size-4 text-primary" aria-hidden />
        <div>
          <span className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Monitoring
          </span>
          <span className="font-mono text-xs font-bold uppercase tracking-wider text-foreground">
            {zone?.label}
            {zone?.room ? ` — ${zone.room}` : ''}
          </span>
        </div>
        <span
          className="ml-auto rounded-sm px-2 py-1 font-mono text-[9px] font-bold uppercase tracking-widest"
          style={{ color: `var(--${status})`, backgroundColor: `color-mix(in oklch, var(--${status}) 15%, transparent)` }}
        >
          {status}
        </span>
      </div>

      <h4 className="mb-2 mt-4 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        Live Sensor Readings
      </h4>
      <ul className="flex flex-col gap-2.5">
        {sensors.map((sensor) => {
          const Icon = SENSOR_ICONS[sensor.key]
          const color = SENSOR_STATUS_COLOR[sensor.status]
          return (
            <li key={sensor.key} className="rounded-md border border-border bg-secondary/30 p-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2">
                  <Icon className="size-3.5 text-muted-foreground" aria-hidden />
                  <span className="font-mono text-[11px] uppercase tracking-wider text-foreground">{sensor.label}</span>
                </span>
                <span className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold tabular-nums text-foreground">
                    {sensor.value}
                    {sensor.unit}
                  </span>
                  <span
                    className="font-mono text-[9px] font-bold uppercase tracking-widest"
                    style={{ color }}
                  >
                    {sensor.status}
                  </span>
                </span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-background/70">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(4, sensor.fill)}%`, backgroundColor: color }}
                />
              </div>
            </li>
          )
        })}
      </ul>
    </Panel>
  )
}

export function ManualOverride() {
  const { selectedZone, manualOverride, setManualOverride } = useDashboard()
  const zone = ZONE_LIST.find((z) => z.id === selectedZone)

  return (
    <Panel title={`Manual Override — ${zone?.label ?? ''}`}>
      <p className="mb-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
        Engage manual control to lock the board and broadcast an operator-directed evacuation, overriding automated
        routing.
      </p>
      <button
        type="button"
        onClick={() => setManualOverride(!manualOverride)}
        aria-pressed={manualOverride}
        className={cn(
          'flex w-full items-center justify-center gap-2.5 rounded-md border px-4 py-3 font-mono text-xs font-bold uppercase tracking-widest transition-all',
          manualOverride
            ? 'border-caution/60 bg-caution/15 text-caution glow-danger'
            : 'border-border bg-secondary/50 text-muted-foreground hover:border-primary/40 hover:text-foreground',
        )}
      >
        {manualOverride ? <Lock className="size-4" aria-hidden /> : <LockOpen className="size-4" aria-hidden />}
        {manualOverride ? 'Override Engaged' : 'Engage Override'}
      </button>
      {manualOverride ? (
        <p className="mt-3 rounded-md border border-caution/40 bg-caution/10 p-2.5 text-center font-mono text-[11px] font-semibold uppercase tracking-wider text-caution animate-blink">
          Operator control active
        </p>
      ) : null}
    </Panel>
  )
}
