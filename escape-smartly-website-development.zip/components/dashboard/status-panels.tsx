'use client'

import { ArrowLeft, ArrowRight, Bell, CircleCheck, Navigation, Route, ShieldCheck, TriangleAlert } from 'lucide-react'
import type { Scenario } from '@/lib/dedb'
import { Panel } from './panel'
import { useDashboard } from './dashboard-context'
import { cn } from '@/lib/utils'

function levelStyles(level: Scenario['level']) {
  switch (level) {
    case 'danger':
      return { color: 'text-danger', ring: 'border-danger/50 bg-danger/10', Icon: TriangleAlert }
    case 'caution':
      return { color: 'text-caution', ring: 'border-caution/50 bg-caution/10', Icon: TriangleAlert }
    default:
      return { color: 'text-safe', ring: 'border-safe/50 bg-safe/10', Icon: ShieldCheck }
  }
}

export function SystemStatusCard() {
  const { scenario } = useDashboard()
  const { color, ring, Icon } = levelStyles(scenario.level)

  return (
    <Panel title="System Status" marker="▶">
      <div className={cn('rounded-md border p-3', ring)}>
        <div className="flex items-center gap-2">
          <Icon className={cn('size-4', color)} aria-hidden />
          <span className={cn('font-mono text-xs font-bold uppercase tracking-wider', color)}>
            {scenario.level === 'normal' ? 'All Systems Normal' : `${scenario.name} Active`}
          </span>
        </div>
        <p className="mt-2 font-mono text-[11px] leading-relaxed text-foreground/90">{scenario.message}</p>
      </div>
    </Panel>
  )
}

export function EvacuationPath() {
  const { scenario } = useDashboard()
  const active = scenario.level !== 'normal'
  const arrowLeft = scenario.direction.trim().startsWith('←')
  const arrowRight = scenario.direction.trim().endsWith('→')

  return (
    <Panel title="Evacuation Path" marker="▶">
      <div
        className={cn(
          'flex flex-col items-center gap-2 rounded-md border p-4 text-center transition-colors',
          active ? 'border-primary/50 bg-primary/10' : 'border-safe/40 bg-safe/5',
        )}
      >
        <div className={cn('flex items-center gap-3 font-mono text-lg font-bold uppercase tracking-wider', active ? 'text-primary text-glow' : 'text-safe')}>
          {arrowLeft ? <ArrowLeft className="size-6 animate-flow" aria-hidden /> : null}
          <span>{scenario.direction}</span>
          {arrowRight ? <ArrowRight className="size-6 animate-flow" aria-hidden /> : null}
          {!arrowLeft && !arrowRight ? <Navigation className="size-5" aria-hidden /> : null}
        </div>
      </div>
      <div className="mt-3 flex items-start gap-2 rounded-md border border-border bg-secondary/40 p-3">
        <Route className="mt-0.5 size-3.5 shrink-0 text-primary" aria-hidden />
        <p className="font-mono text-[11px] leading-relaxed text-muted-foreground">{scenario.evacuationPath}</p>
      </div>
    </Panel>
  )
}

export function AlertLog() {
  const { scenario } = useDashboard()
  const alerts = scenario.alerts

  return (
    <Panel title="Alert Log" marker="▶" action={
      <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        <Bell className="size-3.5" aria-hidden /> {alerts.length}
      </span>
    }>
      {alerts.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border py-8">
          <CircleCheck className="size-6 text-safe" aria-hidden />
          <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            No active alerts
          </span>
        </div>
      ) : (
        <ul className="flex flex-col gap-2" aria-live="polite">
          {alerts.map((alert) => (
            <li
              key={alert.id}
              className="animate-fade-up rounded-md border border-border bg-secondary/40 p-2.5"
              style={{ borderLeftColor: `var(--${alert.level === 'blocked' ? 'blocked' : alert.level})`, borderLeftWidth: 3 }}
            >
              <div className="flex items-center justify-between gap-2">
                <span
                  className="font-mono text-[10px] font-bold uppercase tracking-wider"
                  style={{ color: `var(--${alert.level === 'blocked' ? 'blocked' : alert.level})` }}
                >
                  {alert.zone}
                </span>
                <time className="font-mono text-[10px] tabular-nums text-muted-foreground">+{alert.time}</time>
              </div>
              <p className="mt-1 font-mono text-[11px] leading-snug text-foreground/90">{alert.message}</p>
            </li>
          ))}
        </ul>
      )}
    </Panel>
  )
}

export function StatusBanner() {
  const { scenario } = useDashboard()
  const { color, ring, Icon } = levelStyles(scenario.level)

  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-lg border px-4 py-3.5 transition-colors',
        ring,
        scenario.level === 'danger' && 'glow-danger',
      )}
      role="status"
      aria-live="polite"
    >
      <span className={cn('grid size-10 shrink-0 place-items-center rounded-md border border-current/30', color)}>
        <Icon className={cn('size-5', scenario.level === 'danger' && 'animate-pulse')} aria-hidden />
      </span>
      <div className="min-w-0">
        <span className={cn('font-mono text-xs font-bold uppercase tracking-widest', color)}>
          {scenario.level === 'normal' ? 'System Normal' : 'Active Incident'}
        </span>
        <p className="font-mono text-[12px] leading-snug text-foreground/90 sm:text-sm">{scenario.message}</p>
      </div>
    </div>
  )
}
