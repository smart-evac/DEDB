import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

interface PanelProps {
  title?: string
  marker?: '◈' | '▶'
  className?: string
  bodyClassName?: string
  action?: ReactNode
  children: ReactNode
}

export function Panel({ title, marker = '◈', className, bodyClassName, action, children }: PanelProps) {
  return (
    <section
      className={cn(
        'rounded-lg border border-border bg-panel/70 backdrop-blur-sm',
        className,
      )}
    >
      {title ? (
        <header className="flex items-center justify-between gap-2 border-b border-border/70 px-4 py-2.5">
          <h3 className="flex items-center gap-2 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-primary">
            <span aria-hidden className="text-primary/70">
              {marker}
            </span>
            {title}
          </h3>
          {action}
        </header>
      ) : null}
      <div className={cn('p-4', bodyClassName)}>{children}</div>
    </section>
  )
}
