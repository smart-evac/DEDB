'use client'

import { ArrowLeft, ArrowRight, Hand, Navigation } from 'lucide-react'
import { Panel } from './panel'
import { useDashboard } from './dashboard-context'
import { cn } from '@/lib/utils'

export function EvacuationBoard() {
  const { scenario, manualOverride } = useDashboard()

  const arrowLeft = scenario.direction.trim().startsWith('←')
  const arrowRight = scenario.direction.trim().endsWith('→')
  const danger = scenario.level === 'danger'

  return (
    <Panel title="Dynamic Direction Display" marker="◈" bodyClassName="p-4 sm:p-6">
      <div
        className={cn(
          'relative flex min-h-40 flex-col items-center justify-center gap-3 overflow-hidden rounded-lg border p-6 text-center transition-colors',
          manualOverride
            ? 'border-caution/60 bg-caution/10'
            : danger
              ? 'border-danger/50 bg-danger/10'
              : 'border-safe/50 bg-safe/5',
        )}
        role="status"
        aria-live="assertive"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
          {manualOverride ? 'Manual Operator Control' : danger ? 'Rerouting Active' : 'Standard Signage'}
        </span>

        {manualOverride ? (
          <div className="flex items-center gap-3 font-mono text-2xl font-black uppercase tracking-wider text-caution text-glow sm:text-4xl">
            <Hand className="size-8 animate-pulse sm:size-10" aria-hidden />
            Follow Staff
          </div>
        ) : (
          <div
            className={cn(
              'flex items-center gap-4 font-mono text-3xl font-black uppercase tracking-wider sm:text-5xl',
              danger ? 'text-danger text-glow' : 'text-safe',
            )}
          >
            {arrowLeft ? <ArrowLeft className="size-9 animate-flow sm:size-12" aria-hidden /> : null}
            <span>{scenario.direction}</span>
            {arrowRight ? <ArrowRight className="size-9 animate-flow sm:size-12" aria-hidden /> : null}
            {!arrowLeft && !arrowRight ? <Navigation className="size-8 sm:size-10" aria-hidden /> : null}
          </div>
        )}

        <p className="max-w-md font-mono text-[11px] leading-relaxed text-foreground/80 sm:text-xs">
          {manualOverride ? 'Automated routing suspended — proceed under staff direction.' : scenario.evacuationPath}
        </p>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-md border border-border bg-secondary/40 p-3">
          <span className="mb-1 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
            Normal
          </span>
          <span className="flex items-center justify-center gap-2 font-mono text-sm font-bold uppercase text-safe">
            Exit <ArrowRight className="size-4" aria-hidden />
          </span>
        </div>
        <div className="rounded-md border border-danger/40 bg-danger/5 p-3">
          <span className="mb-1 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
            Route Unsafe
          </span>
          <span className="flex items-center justify-center gap-2 font-mono text-sm font-bold uppercase text-danger">
            <ArrowLeft className="size-4" aria-hidden /> Safe Exit
          </span>
        </div>
      </div>
    </Panel>
  )
}
